// Teste slider
console.log('slider');